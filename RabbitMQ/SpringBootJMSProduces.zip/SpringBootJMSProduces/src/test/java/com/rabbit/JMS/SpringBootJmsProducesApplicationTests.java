package com.rabbit.JMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJmsProducesApplicationTests {

	@Test
	void contextLoads() {
	}

}
